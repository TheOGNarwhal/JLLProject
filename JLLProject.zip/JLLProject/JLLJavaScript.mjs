var myTable = document.getElementById("AddressTable");
var addButton = document.getElementById("addButton");
var Users = []
var Count = 1
var check = false

var populateData = function(){
    const Http = new XMLHttpRequest();
        const url='http://localhost:5014/';
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                var myUsers = JSON.parse(Http.responseText)
                myUsers.forEach(userToAdd => {
                    createRow(userToAdd) 
                });
            }}
}

var selectUser = function(){
    const Http = new XMLHttpRequest();
        const url='http://localhost:5014/latestUser';
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                var myUser = JSON.parse(Http.responseText)
                    createRow(myUser) 
            }}
}

addButton.addEventListener("click", function(){
    var User = []
    var i = 0
    var tableRows = document.getElementsByTagName("tr")
    var cells =  tableRows[1].cells
    for( k = 1; k < cells.length - 1; k++){
        User[i] = cells[k].firstElementChild.value.toString()
        i++
    }
    var newUser = {
        FirstName: User[0],
        LastName: User[1],
        Address: User[2],
        PhoneNumber: User[3],
        Type: User[4],
        Group: User[5]
    }
    newUser = valueCheck(newUser)
    //Sending Server Request
    const Http = new XMLHttpRequest();
    const url=`http://localhost:5014/add/${newUser.FirstName}&${newUser.LastName}&${newUser.Address}&${newUser.PhoneNumber}&${newUser.Type}&${newUser.Group}`;
    Http.open("GET", url);
    Http.send();
    Http.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            if(Http.responseText == 1){
                selectUser()
                resetUser() 
                alert("User Added Successfuly")
            } else{
                alert("User Failed to add...")
            }
        }}
});

var valueCheck = function(userToCheck){
    if(userToCheck.LastName == null || userToCheck.LastName == ""){
        userToCheck.LastName = "NONE"
    } if(userToCheck.Address == null || userToCheck.Address == ""){
        userToCheck.Address = "NONE"
    }
    return userToCheck
}

var resetUser = function(){
    var tableRows = document.getElementsByTagName("tr")
                var cells =  tableRows[1].cells
                for( k = 1; k < cells.length - 1; k++){
                    if(k == 5|| k == 6){
                        cells[k].firstElementChild.value = 1
                    } else{
                        cells[k].firstElementChild.value = ""
                    }
                }
}

var createRow = function(data){
    //Creating New Row
    var newRow =  myTable.insertRow(myTable.rows.length)
    
    //Creating First Cell In table and giving some styling
    var userNumber  = newRow.insertCell(0)
    userNumber.style = "text-align: center"
    var userCount = document.createTextNode(Count.toString())

    //Creating Cells in table
    var FirstName  = newRow.insertCell(1)
    var LastName  = newRow.insertCell(2)
    var Address  = newRow.insertCell(3)
    var PhoneNumber  = newRow.insertCell(4)
    var PhoneType  = newRow.insertCell(5)
    var PhoneGroup  = newRow.insertCell(6)
    var id = newRow.insertCell(7)
    var Delete  = newRow.insertCell(8)
    var Update  = newRow.insertCell(9)
    id.hidden = true
    
    //Setting Cells to TextBoxs 
    var TextBoxOne  = document.createElement("input")
    TextBoxOne.style = "width: 99%"
    TextBoxOne.value = data.FirstName
    var TextBoxTwo  = document.createElement("input")
    TextBoxTwo.style = "width: 99%"
    TextBoxTwo.value = data.LastName
    var TextBoxThree  = document.createElement("input")
    TextBoxThree.style = "width: 99%"
    TextBoxThree.value = data.Address
    var TextBoxFour  = document.createElement("input")
    TextBoxFour.style = "width: 99%"
    TextBoxFour.value = data.PhoneNumber
    var TextBoxFive  = document.createElement("input")
    TextBoxFive.style = "width: 99%"
    TextBoxFive.value = data.ID

    //Phone Type Dropdown Menu
    var SelectBoxOne  = document.createElement("select")
    var OptionOne = document.createElement("option")
    OptionOne.text = "Work"; OptionOne.value = 1
    var OptionTwo = document.createElement("option")
    OptionTwo.text = "Home"; OptionTwo.value = 2
    var OptionThree = document.createElement("option")
    OptionThree.text = "Cell"; OptionThree.value = 3
    SelectBoxOne.add(OptionOne)
    SelectBoxOne.add(OptionTwo)
    SelectBoxOne.add(OptionThree)
    var optionsOne = [OptionOne, OptionTwo, OptionThree]
    optionsOne.forEach(text => {
        if(text.text == data.Type){
            SelectBoxOne.selectedIndex = optionsOne.indexOf(text)
        }
    });
    //Phone Group Dropdown Mennu
    var SelectBoxTwo  = document.createElement("select")
    var OptionFour = document.createElement("option")
    OptionFour.text = "Work"; OptionFour.value = 1
    var OptionFive = document.createElement("option")
    OptionFive.text = "Family"; OptionFive.value = 2
    var OptionSix = document.createElement("option")
    OptionSix.text = "Friends"; OptionSix.value = 3
    SelectBoxTwo.add(OptionFour)
    SelectBoxTwo.add(OptionFive)
    SelectBoxTwo.add(OptionSix)
    var optionsTwo = [OptionFour, OptionFive, OptionSix]
    optionsTwo.forEach(newOption => {
        if(newOption.text == data.Group){
            SelectBoxTwo.selectedIndex = optionsTwo.indexOf(newOption)
        }
    });
    
    //Delete Button Options
    var ButtonOne  = document.createElement("button")
    ButtonOne.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(255, 6, 6);"
    ButtonOne.id = "DeleteButton" + Count
    var DeleteText = document.createTextNode("Delete")
    ButtonOne.appendChild(DeleteText)
    ButtonOne.value = Count


    //Update Button Options
    var ButtonTwo  = document.createElement("button")
    ButtonTwo.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(38, 153, 247);"
    ButtonTwo.id = "UpdateButton" + Count
    var UpdateText = document.createTextNode("Update")
    ButtonTwo.appendChild(UpdateText)

    //Finalization of all cells
    userNumber.appendChild(userCount)
    FirstName.appendChild(TextBoxOne)
    LastName.appendChild(TextBoxTwo)
    Address.appendChild(TextBoxThree)
    PhoneNumber.appendChild(TextBoxFour)
    PhoneType.appendChild(SelectBoxOne)
    PhoneGroup.appendChild(SelectBoxTwo)
    id.appendChild(TextBoxFive)
    Delete.appendChild(ButtonOne)
    Update.appendChild(ButtonTwo)
    eventCreation()
    Count++
}

var eventCreation = function(){
    var element = "DeleteButton" + Count
    var deleteUserButton = document.getElementById(element)
    deleteUserButton.addEventListener('click', function(){
        //GEtting the current row
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(deleteUserButton)){
                var param = i
            }
        }
         //Getting all the information about a user
         var User = []
         var i = 0
         var cells =  tableRows[param].cells
         for( k = 1; k < cells.length - 2; k++){
             User[i] = cells[k].firstChild.value.toString()
             i++
         }
 
         //Sending Server Request
         const Http = new XMLHttpRequest();
         const url=`http://localhost:5014/delete/${User[6]}`;
         Http.open("GET", url);
         Http.send();
         Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                if(Http.responseText == 1){
                    alert("User Deleted Successfuly!")
                    myTable.deleteRow(param)
                }else{
                    alert("User Deleted Failed...")
                }
            }}
    })
    var element = "UpdateButton" + Count
    var updateUserButton = document.getElementById(element)
    updateUserButton.addEventListener('click', function(){
        //Finding the current Row
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(updateUserButton)){
                var param = i
            }
        }

        //Getting all the information about a user
        var User = []
        var i = 0
        var cells =  tableRows[param].cells
        for( k = 1; k < cells.length - 2; k++){
            User[i] = cells[k].firstChild.value.toString()
            i++
        }

        //Creating a User Object
        var newUser = {
            FirstName: User[0],
            LastName: User[1],
            Address: User[2],
            PhoneNumber: User[3],
            Type: User[4],
            Group: User[5],
            ID: User[6]
        }
        newUser = valueCheck(newUser)
         //Sending Server Request
        const Http = new XMLHttpRequest();
        const url=`http://localhost:5014/update/${newUser.ID}&${newUser.FirstName}&${newUser.LastName}&${newUser.Address}&${newUser.PhoneNumber}&${newUser.Type}&${newUser.Group}`;
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                if(Http.responseText == 1){
                    alert("User Updated Successfuly")
                } else{
                    alert("User Failed to update...")
                }
            }}
    })
}

populateData()