const sql = require('mssql');
const express = require('express');
const app = express();
var newUsers = []

const config = {
    server: "127.0.0.1",
    database: "AddressBook",
    user: "Narwhal",
    password: "KJB51014",
    port: 514
}

app.listen('5014', () => {
    console.log('Server Started')
})

app.get('/', (req, res) => {
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectAllUsers')
    }).then(result => {
        var Users = result.recordset
        var userCount = Users.length
        var i = 0
        while(i < userCount){
            newUsers[i] = {
                ID: result.recordset[i].ID,
                FirstName: result.recordset[i].FirstName,
                LastName: result.recordset[i].LastName,
                Address: result.recordset[i].Adress,
                PhoneNumber:  result.recordset[i].PhoneNumber,
                Type: result.recordset[i].Name[0],
                Group: result.recordset[i].Name[1]
            }
            i++
        }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUsers)
        newUsers = []
    }).catch(err => {
        sql.close()
        newUsers = []
    })
})

app.get('/latestUser', (req, res) => {
    var newUser = {}
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectLatestUser')
    }).then(result => {
             newUser = {
                ID: result.recordset[0].ID,
                FirstName: result.recordset[0].FirstName,
                LastName: result.recordset[0].LastName,
                Address: result.recordset[0].Adress,
                PhoneNumber:  result.recordset[0].PhoneNumber,
                Type: result.recordset[0].Name[0],
                Group: result.recordset[0].Name[1]
            }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUser)
        newUser = {}
    }).catch(err => {
        sql.close()
    })
})

app.get('/delete/:id', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('key', sql.Int, req.params.id)
        .execute('sp_UserDelete')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        sql.close()
    })
})

app.get('/add/:FirstName&:LastName&:Address&:PhoneNumber&:Type&:Group', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('FirstName', sql.VarChar, req.params.FirstName)
        .input('LastName', sql.VarChar, req.params.LastName)
        .input('Address', sql.VarChar, req.params.Address)
        .input('PhoneNumber', sql.VarChar, req.params.PhoneNumber)
        .input('PhoneType', sql.Int, req.params.Type)
        .input('Group', sql.Int, req.params.Group)
        .execute('sp_UserAdd')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
})

app.get('/update/:id&:FirstName&:LastName&:Address&:PhoneNumber&:Type&:Group', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('ID', sql.Int, req.params.id)
        .input('FirstName', sql.VarChar, req.params.FirstName)
        .input('LastName', sql.VarChar, req.params.LastName)
        .input('Address', sql.VarChar, req.params.Address)
        .input('PhoneNumber', sql.VarChar, req.params.PhoneNumber)
        .input('PhoneType', sql.Int, req.params.Type)
        .input('Group', sql.Int, req.params.Group)
        .execute('sp_UserUpdate')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
})

function deleteUser(userToDelete){ 
    sql.connect(config).then(pool => {

        return pool.request()
        .input('key', sql.Int, userToDelete)
        .execute('sp_UserDelete')
    }).then(result => {
        sql.close()
        console.log("User deleted!")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
}

function addUser(userToAdd){ 
    sql.connect(config).then(pool => {

        return pool.request()
        .input('FirstName', sql.VarChar, userToAdd.FirstName)
        .input('LastName', sql.VarChar, userToAdd.LastName)
        .input('Address', sql.VarChar, userToAdd.Address)
        .input('PhoneNumber', sql.VarChar, userToAdd.PhoneNumber)
        .input('PhoneType', sql.Int, userToAdd.Type)
        .input('Group', sql.Int, userToAdd.Group)
        .execute('sp_UserAdd')
    }).then(result => {
        sql.close()
        console.log("User Added!")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
}

function updateUser(userToUpdate){ 
    sql.connect(config).then(pool => {

        return pool.request()
        .input('ID', sql.Int, userToUpdate.ID)
        .input('FirstName', sql.VarChar, userToUpdate.FirstName)
        .input('LastName', sql.VarChar, userToUpdate.LastName)
        .input('Address', sql.VarChar, userToUpdate.Address)
        .input('PhoneNumber', sql.VarChar, userToUpdate.PhoneNumber)
        .input('PhoneType', sql.Int, userToUpdate.Type)
        .input('Group', sql.Int, userToUpdate.Group)
        .execute('sp_UserUpdate')
    }).then(result => {
        sql.close()
        console.log("User Updated!")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
}

var createRow = function(data){
    //variables
    var myTable = document.getElementById("AddressTable");
    var addButton = document.getElementById("Create");
    var dummydata = [{
        FirstName: "Joshua",
        LastName: "Mills",
        Address: "some Place",
        PhoneNumber: "8012896880",
        Type: 0,
        Group: 1
    },
    {
        FirstName: "Alexander",
        LastName: "Odria",
        Address: "new place",
        PhoneNumber: "801289200",
        Type: 2,
        Group: 2
    }]
    var Users = []
    var Count = 1
    var check = false

    //Creating New Row
    var newRow =  myTable.insertRow(myTable.rows.length)
    var userNumber  = newRow.insertCell(0)
    
    //Creating First Cell In table and giving some styling
    userNumber.style = "text-align: center"
    var userCount = document.createTextNode(Count.toString())

    //Creating Cells in table
    var FirstName  = newRow.insertCell(1)
    var LastName  = newRow.insertCell(2)
    var Address  = newRow.insertCell(3)
    var PhoneNumber  = newRow.insertCell(4)
    var PhoneType  = newRow.insertCell(5)
    var PhoneGroup  = newRow.insertCell(6)
    var Delete  = newRow.insertCell(7)
    var Update  = newRow.insertCell(8)
    
    //Setting Cells to TextBoxs 
    var TextBoxOne  = document.createElement("input")
    TextBoxOne.style = "width: 99%"
    TextBoxOne.value = data.FirstName
    var TextBoxTwo  = document.createElement("input")
    TextBoxTwo.style = "width: 99%"
    TextBoxTwo.value = data.LastName
    var TextBoxThree  = document.createElement("input")
    TextBoxThree.style = "width: 99%"
    TextBoxThree.value = data.Address
    var TextBoxFour  = document.createElement("input")
    TextBoxFour.style = "width: 99%"
    TextBoxFour.value = data.PhoneNumber

    //Phone Type Dropdown Menu
    var SelectBoxOne  = document.createElement("select")
    var OptionOne = document.createElement("option")
    OptionOne.text = "Work"; OptionOne.value = 1
    var OptionTwo = document.createElement("option")
    OptionTwo.text = "Home"; OptionTwo.value = 2
    var OptionThree = document.createElement("option")
    OptionThree.text = "Cell"; OptionThree.value = 3
    SelectBoxOne.add(OptionOne)
    SelectBoxOne.add(OptionTwo)
    SelectBoxOne.add(OptionThree)
    SelectBoxOne.selectedIndex = data.Type

    //Phone Group Dropdown Mennu
    var SelectBoxTwo  = document.createElement("select")
    var OptionFour = document.createElement("option")
    OptionFour.text = "Work"; OptionFour.value = 1
    var OptionFive = document.createElement("option")
    OptionFive.text = "Family"; OptionFive.value = 2
    var OptionSix = document.createElement("option")
    OptionSix.text = "Friends"; OptionSix.value = 3
    SelectBoxTwo.add(OptionFour)
    SelectBoxTwo.add(OptionFive)
    SelectBoxTwo.add(OptionSix)
    SelectBoxTwo.selectedIndex = data.Group
    
    //Delete Button Options
    var ButtonOne  = document.createElement("button")
    ButtonOne.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(255, 6, 6);"
    ButtonOne.id = "DeleteButton" + Count
    var DeleteText = document.createTextNode("Delete")
    ButtonOne.appendChild(DeleteText)
    ButtonOne.value = Count


    //Update Button Options
    var ButtonTwo  = document.createElement("button")
    ButtonTwo.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(38, 153, 247);"
    ButtonTwo.id = "UpdateButton" + Count
    var UpdateText = document.createTextNode("Update")
    ButtonTwo.appendChild(UpdateText)

    //Finalization of all cells
    userNumber.appendChild(userCount)
    FirstName.appendChild(TextBoxOne)
    LastName.appendChild(TextBoxTwo)
    Address.appendChild(TextBoxThree)
    PhoneNumber.appendChild(TextBoxFour)
    PhoneType.appendChild(SelectBoxOne)
    PhoneGroup.appendChild(SelectBoxTwo)
    Delete.appendChild(ButtonOne)
    Update.appendChild(ButtonTwo)
    eventCreation()
    Count++
}

var eventCreation = function(){
    var element = "DeleteButton" + Count
    var deleteUserButton = document.getElementById(element)
    deleteUserButton.addEventListener('click', function(){
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(deleteUserButton)){
                var param = i
            }
        }
        myTable.deleteRow(param)
    })
    var element = "UpdateButton" + Count
    var updateUserButton = document.getElementById(element)
    updateUserButton.addEventListener('click', function(){
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(updateUserButton)){
                var param = i
            }
        }

        var User = ""
        var cells =  tableRows[param].cells
        for( k = 1; k < cells.length - 2; k++){
            User = User + cells[k].firstChild.value.toString() + ","
        }
        User.replace("undefined","")
        alert(User)
    })
}
